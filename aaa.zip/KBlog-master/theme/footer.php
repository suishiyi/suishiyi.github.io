<!--
 * Krunk.cn KBlog - 极简博客
 *
 * Project Link: https://kblog.krunk.cn
 * GitHub: https://github.com/KrunkZhou/KBlog
 * 
 * @author     Krunk Zhou
 * @copyright  2019 Krunk Zhou (https://krunk.cn)
-->

<br><br><br>
<footer>
	<p><? echo $site_footer ?></p><br>
	<p>Proudly Powered by</p>
	<a href="https://krunk.cn" target="_blank"><img class="bottomlogo" src="https://image.krunk.cn/images/2019/12/15/logo-krunk-kblog.png"></a><br><br>
</footer>
<script src="<? echo $theme_folder ?>/js/main.js"></script>
<script src="<? echo $data_folder ?>/style.js"></script>